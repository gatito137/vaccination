-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2022 at 11:42 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bd_vaccination`
--
CREATE DATABASE IF NOT EXISTS `bd_vaccination` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `bd_vaccination`;

-- --------------------------------------------------------

--
-- Table structure for table `tabemployees`
--

DROP TABLE IF EXISTS `tabemployees`;
CREATE TABLE `tabemployees` (
  `id` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `job` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vaccine` int(11) NOT NULL,
  `doses` int(11) NOT NULL,
  `dateDose` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `tabemployees`:
--   `vaccine`
--       `tabvaccines` -> `id`
--   `job`
--       `tabjobs` -> `id`
--

--
-- Dumping data for table `tabemployees`
--

INSERT INTO `tabemployees` VALUES(1, 'gatito', 3, 'full', 2, 2, '2-2-2022');
INSERT INTO `tabemployees` VALUES(2, 'chan', 2, 'medium', 4, 1, '2-2-2022');

-- --------------------------------------------------------

--
-- Table structure for table `tabjobs`
--

DROP TABLE IF EXISTS `tabjobs`;
CREATE TABLE `tabjobs` (
  `id` int(11) NOT NULL,
  `job` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `tabjobs`:
--

--
-- Dumping data for table `tabjobs`
--

INSERT INTO `tabjobs` VALUES(1, 'sales');
INSERT INTO `tabjobs` VALUES(2, 'administration');
INSERT INTO `tabjobs` VALUES(3, 'developer');
INSERT INTO `tabjobs` VALUES(4, 'rrhh');

-- --------------------------------------------------------

--
-- Table structure for table `tabpermissions`
--

DROP TABLE IF EXISTS `tabpermissions`;
CREATE TABLE `tabpermissions` (
  `id` int(11) NOT NULL,
  `permission` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `tabpermissions`:
--

-- --------------------------------------------------------

--
-- Table structure for table `tabusers`
--

DROP TABLE IF EXISTS `tabusers`;
CREATE TABLE `tabusers` (
  `id` int(11) NOT NULL,
  `user` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `permission` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `tabusers`:
--   `permission`
--       `tabpermissions` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabvaccines`
--

DROP TABLE IF EXISTS `tabvaccines`;
CREATE TABLE `tabvaccines` (
  `id` int(11) NOT NULL,
  `vaccine` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `doses` int(11) NOT NULL,
  `amountDays` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `tabvaccines`:
--

--
-- Dumping data for table `tabvaccines`
--

INSERT INTO `tabvaccines` VALUES(1, 'Sinopharm', 2, 30);
INSERT INTO `tabvaccines` VALUES(2, 'AstraZeneca', 2, 60);
INSERT INTO `tabvaccines` VALUES(3, 'Sputnik V', 2, 60);
INSERT INTO `tabvaccines` VALUES(4, 'Pfizer', 2, 21);
INSERT INTO `tabvaccines` VALUES(5, 'Moderna', 2, 28);
INSERT INTO `tabvaccines` VALUES(6, 'Janssen', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabemployees`
--
ALTER TABLE `tabemployees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vaccine` (`vaccine`),
  ADD KEY `job` (`job`);

--
-- Indexes for table `tabjobs`
--
ALTER TABLE `tabjobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabpermissions`
--
ALTER TABLE `tabpermissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabusers`
--
ALTER TABLE `tabusers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission` (`permission`);

--
-- Indexes for table `tabvaccines`
--
ALTER TABLE `tabvaccines`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabemployees`
--
ALTER TABLE `tabemployees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tabjobs`
--
ALTER TABLE `tabjobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tabpermissions`
--
ALTER TABLE `tabpermissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tabusers`
--
ALTER TABLE `tabusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tabvaccines`
--
ALTER TABLE `tabvaccines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tabemployees`
--
ALTER TABLE `tabemployees`
  ADD CONSTRAINT `tabemployees_ibfk_1` FOREIGN KEY (`vaccine`) REFERENCES `tabvaccines` (`id`),
  ADD CONSTRAINT `tabemployees_ibfk_2` FOREIGN KEY (`job`) REFERENCES `tabjobs` (`id`);

--
-- Constraints for table `tabusers`
--
ALTER TABLE `tabusers`
  ADD CONSTRAINT `tabusers_ibfk_1` FOREIGN KEY (`permission`) REFERENCES `tabpermissions` (`id`);


--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata for table tabemployees
--

--
-- Metadata for table tabjobs
--

--
-- Metadata for table tabpermissions
--

--
-- Metadata for table tabusers
--

--
-- Metadata for table tabvaccines
--

--
-- Metadata for database bd_vaccination
--
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
